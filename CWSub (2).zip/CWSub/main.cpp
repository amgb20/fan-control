/**
* @author Alexandre BENOIT
* @version 1.0 15/12/2022
* 
* Fan control: Integrated Engineering, EE30186
* Submission Date: 16/12/2022
* 
* The software is designed the control the speed of a three-pin fan. It is controlled via different user
* inputs displayed on the UI (LCD) for a better UX.
* More information can be found in the README.md
*/

#include "mbed.h"
#include <cstdint>
#include <cstdio>
#include<stdio.h>
#include "Encoder.h"
#include "TextLCD.h"
#include <chrono>

/**
 * Defines
 */
#define ROTARY_A PA_1 // Encoder pinA
#define ROTARY_B PA_4 // Encoder pinB
#define LED_2    PB_7 // BiDir A
#define LED_3    PA_15 // BiDir B


PinName Rotary_A(ROTARY_A);
PinName Rotary_B(ROTARY_B);
InterruptIn Button(BUTTON1);
DigitalOut Led_3(LED_3);
DigitalOut Led_2(LED_2);
DigitalOut Led_board(LED1);

/**
* Creating the TextLCD object
*/
TextLCD lcd_2(PB_5,PB_4,PC_7,PB_6,PA_7,PA_6);

/**
* Creating the QEI_ object
*/
QEI_ myQEI(Rotary_A, Rotary_B);

/**
* Creating different timer
* @param timer_3 Timer used for Animation Introduction.
* @param timer_4 Timer used for Animation Message.
*/
Timer timer_3;  
Timer timer_4; 
Timer MenuTimer_;

/**
* Creating boolean function to handle the menu selection.
* @param mode Initialize the mode choosen for the menu.
* @param selectedFlag Initialize a flag to trigger an even.
*/
bool mode = 0; 
bool selectedFlag; 

/**
* Creates an introduction animation on the LCD.
* @param countColumnA counter to loop to shift text.
* @param countColumnB counter to loop to shift text.
* @param int_us_animation static integer for a time counter.
* @return None.
*/
void AnimationIntro(void)
{

    static uint64_t int_us_animation = 0;

    timer_3.start();

    int countColumnA = 0; int countColumnB = 12;

    while(int_us_animation < 10e6)
    {

    int_us_animation = timer_3.elapsed_time().count();

    lcd_2.cls();
    lcd_2.locate(countColumnA,0);
    lcd_2.printf("Speed Fan");

    lcd_2.locate(countColumnA,1);
    lcd_2.printf("Control");

    countColumnA++;
    countColumnB--;

        if(countColumnA == 7) // Have a look at the number of counts needed so it does not overlay
        {
            countColumnA=0;
        }

        if(countColumnB == 0)
        {
            countColumnB = 12;
        }
    thread_sleep_for(1000);
    }
}

/**
* In progress
*/
void AnimationBullet()
{
    int a1[8];

    a1[0] = 0x00;
    a1[1] = 0x00;
    a1[2] = 0x0E;
    a1[3] = 0x0E;
    a1[4] = 0x0E;
    a1[5] = 0x00;
    a1[6] = 0x00;
    a1[7] = 0x00;

    lcd_2.writeCGRAM(7, a1);
}

/**
* In progress
*/
void AnimationFan()
{
    // /**
    // * Fan array pos 1         
    // */
    // int m1[8];                
    // int m2[8];                
    // int m3[8];                
    // int m4[8];                
    // int m5[8];                
    // int m6[8]; 

    // int n1[8];                
    // int n2[8];                
    // int n3[8];                
    // int n4[8];                
    // int n5[8];                
    // int n6[8];           

    // /**
    // ********** Fan matrix pos 1*************                  
    // */
    // m1[0] = 0x1F;     m2[0] = 0x1F;     m3[0] = 0x1F;     m4[1] = 0x10;      m5[1] = 0x1F;     m6[1] = 0x01;                      
    // m1[1] = 0x18;     m2[1] = 0x00;     m3[1] = 0x03;     m4[0] = 0x10;      m5[0] = 0x1F;     m6[0] = 0x01;                   
    // m1[2] = 0x14;     m2[2] = 0x00;     m3[2] = 0x05;     m4[2] = 0x10;      m5[2] = 0x1F;     m6[2] = 0x01;                   
    // m1[3] = 0x12;     m2[3] = 0x00;     m3[3] = 0x09;     m4[3] = 0x11;      m5[3] = 0x00;     m6[3] = 0x11;                   
    // m1[4] = 0x11;     m2[4] = 0x00;     m3[4] = 0x11;     m4[4] = 0x12;      m5[4] = 0x00;     m6[4] = 0x09;                   
    // m1[5] = 0x10;     m2[5] = 0x1F;     m3[5] = 0x01;     m4[5] = 0x14;      m5[5] = 0x00;     m6[5] = 0x05;                   
    // m1[6] = 0x10;     m2[6] = 0x1F;     m3[6] = 0x01;     m4[6] = 0x18;      m5[6] = 0x00;     m6[6] = 0x03;                   
    // m1[7] = 0x10;     m2[7] = 0x1F;     m3[7] = 0x01;     m4[7] = 0x1F;      m5[7] = 0x1F;     m6[7] = 0x1F; 

    // /**
    // ********** Fan matrix pos 1*************                  
    // */
    // n1[0] = 0x1F;     n2[0] = 0x1F;     n6[0] = 0x1F;     n4[1] = 0x10;      n5[1] = 0x1F;     n3[1] = 0x01;                      
    // n1[1] = 0x18;     n2[1] = 0x00;     n6[1] = 0x03;     n4[0] = 0x10;      n5[0] = 0x1F;     n3[0] = 0x01;                   
    // n1[2] = 0x14;     n2[2] = 0x00;     n6[2] = 0x05;     n4[2] = 0x10;      n5[2] = 0x1F;     n3[2] = 0x01;                   
    // n1[3] = 0x12;     n2[3] = 0x00;     n6[3] = 0x09;     n4[3] = 0x11;      n5[3] = 0x00;     n3[3] = 0x11;                   
    // n1[4] = 0x11;     n2[4] = 0x00;     n6[4] = 0x11;     n4[4] = 0x12;      n5[4] = 0x00;     n3[4] = 0x09;                   
    // n1[5] = 0x10;     n2[5] = 0x1F;     n6[5] = 0x01;     n4[5] = 0x14;      n5[5] = 0x00;     n3[5] = 0x05;                   
    // n1[6] = 0x10;     n2[6] = 0x1F;     n6[6] = 0x01;     n4[6] = 0x18;      n5[6] = 0x00;     n3[6] = 0x03;                   
    // n1[7] = 0x10;     n2[7] = 0x1F;     n6[7] = 0x01;     n4[7] = 0x1F;      n5[7] = 0x1F;     n3[7] = 0x1F; 
    
    // /**
    // * Fan pos1                  
    // */
    // lcd_2.writeCGRAM(1, m1);    
    // lcd_2.writeCGRAM(2, m2);    
    // lcd_2.writeCGRAM(3, m3);    
    // lcd_2.writeCGRAM(4, m4);    
    // lcd_2.writeCGRAM(5, m5);    
    // lcd_2.writeCGRAM(6, m6);    
    

    // // while(int_us_animation < 10*1e6)
    // // while(int_us_animation < 1e6)
    // // {

    //     // int_us_animation = timer_3.elapsed_time().count();

    //     lcd_2.cls();
    //     lcd_2.locate(0, 0);
    //     lcd_2.putc(1);

    //     lcd_2.locate(1, 0);
    //     lcd_2.putc(2);

    //     lcd_2.locate(2, 0);
    //     lcd_2.putc(3);

    //     lcd_2.locate(0, 1);
    //     lcd_2.putc(4);

    //     lcd_2.locate(1, 1);
    //     lcd_2.putc(5);

    //     lcd_2.locate(2, 1);
    //     lcd_2.putc(6);

    //     thread_sleep_for(2000);
    
    // lcd_2.writeCGRAM(1, n1);    
    // lcd_2.writeCGRAM(2, n2);    
    // lcd_2.writeCGRAM(3, n3);    
    // lcd_2.writeCGRAM(4, n4);    
    // lcd_2.writeCGRAM(5, n5);    
    // lcd_2.writeCGRAM(6, n6);  

    //     lcd_2.cls();
    //     lcd_2.locate(0, 0);
    //     lcd_2.putc(1);

    //     lcd_2.locate(1, 0);
    //     lcd_2.putc(2);

    //     lcd_2.locate(2, 0);
    //     lcd_2.putc(3);

    //     lcd_2.locate(0, 1);
    //     lcd_2.putc(4);

    //     lcd_2.locate(1, 1);
    //     lcd_2.putc(5);

    //     lcd_2.locate(2, 1);
    //     lcd_2.putc(6);
        
    //     // lcd_2.cls();
    //     // lcd_2.locate(0, 0);
    //     // lcd_2.putc(1);

    //     // lcd_2.locate(2, 0);
    //     // lcd_2.putc(2);

    //     // lcd_2.locate(5, 0);
    //     // lcd_2.putc(2);
}

/**
* Creates a message animation on the LCD to warn the user that he will need to make a choice
* Creates an introduction animation on the LCD.
* @param countColumnC counter to loop to shift text.
* @param countColumnD counter to loop to shift text.
* @param int_us_animation_2 static integer for a time counter.
* @return None.
*/
void AnimationMenuMessage(void)
{

    static uint64_t int_us_animation_2 = 0;

    timer_4.start();

    int countColumnC = 0; int countColumnD = 12;

    while(int_us_animation_2 < 5e6)
    {

    int_us_animation_2 = timer_4.elapsed_time().count();

    lcd_2.cls();
    lcd_2.locate(countColumnC,0);
    lcd_2.printf("Select option");

    lcd_2.locate(countColumnD,1);
    lcd_2.printf("Below");

    countColumnC++;
    countColumnD--;

        if(countColumnC == 7)
        {
            countColumnC=0;
        }

        if(countColumnD == 0)
        {
            countColumnD = 12;
        }
    thread_sleep_for(500);
    }
}

/**
* ButtonRise is called everytime the BUTTON1 (Blue button situated on the Nucleo Board) is HIGH.
* If the button is pressed more than half a second, it will select the mode.
* @param mode is boolean value that triggers the option that the user selected
* @return None.
*/
void ButtonRise(void)
{
    // Led_3 = 1;
    Led_2 = 1;
    Led_board = 0;
    MenuTimer_.stop();
    if(!selectedFlag && MenuTimer_.elapsed_time().count() < 0.5e6)
    {
        mode = !mode;
        MenuTimer_.reset();
        return;
    }

    selectedFlag  = true;
    MenuTimer_.reset();

}

/**
* ButtonFall is called everytime the BUTTON1 (Blue button situated on the Nucleo Board) is LOW;
* The MenuTimer_ is started
* @return None.
*/
void ButtonFall(void)
{
    Led_2 = 0;
    Led_board = 1;
    MenuTimer_.start();
}

/**
* Prints the layout of the menu displayed to the user on the LCD
* @param countOL counter for the Open Loop Message display
* @param countCL counter for the Closed Loop Message display
* @return None.
*/
void MenuSelectDisplay(void)
{
    int countOL = 7;
    int countCL = 6;

    while(!selectedFlag)
    {
        if(mode == 0)
        {
            for(int r = 0; r < countOL;r++)
            {
                lcd_2.cls();
                lcd_2.locate(0, 0);
                lcd_2.printf("Select option:");
                // lcd_2.cls();
                lcd_2.locate(r, 1);
                lcd_2.printf("Open Loop");
                thread_sleep_for(500);
            }
            
        }
        wait_us(50e1);

        if(mode == 1)
        {
            for(int r = 0; r < countCL;r++)
            {
                lcd_2.cls();
                lcd_2.locate(0, 0);
                lcd_2.printf("Select option:");
                lcd_2.locate(r, 1);
                lcd_2.printf("Closed Loop");
                thread_sleep_for(500);
            }
        }
        wait_us(50e1);
    }
}

//------------------------------------------------ Set-up ---------------------------------------------//

// Entering the main loop
int main()
{

    /**
    * Creating a fall and rise interrupt callback function to trigger the rise and fall of Button
    */
    Button.fall(callback(&ButtonFall));
    Button.rise(callback(&ButtonRise));

    /**
        * Animation
        */
        AnimationIntro();

        /**
        * Menu selection
        */
        AnimationMenuMessage();

        /**
        * Call the MenuSelectDisplay function
        */
        MenuSelectDisplay();

    /**
    * Initializing a while loop to loop through the switch case depending on the user's input.
    */
    while(true)
    {

        /**
        * Creating a switch case to enter the different menu option that the user selected.
        * Case 1 will enter a simple Open Loop control system of the fan
        * Case 2 will enter the Closed Loop control system of the fan
        */
        switch (mode) 
        {
            case 0 :
            {
                myQEI.writePWM_OL();
                break;
            }

            case 1:
            {
                myQEI.writePWM_CL();
                break;
            }
        } 
    }
}