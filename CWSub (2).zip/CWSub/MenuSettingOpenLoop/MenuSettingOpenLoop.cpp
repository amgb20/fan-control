#include "mbed.h"
#include "MenuSettingOpenLoop.h"
#include "TextLCD.h"
#include "PIDControl.h"

#define LED_OL_1  PB_7 // BiDir A
#define LED_OL_2  PA_15 // BiDir B

// Hardware
DigitalOut Led_board_OL_Menu(LED1);
DigitalOut Led_OL_2(LED_OL_2);
DigitalOut Led_OL_1(LED_OL_1);

TextLCD lcd_3(PB_5,PB_4,PC_7,PB_6,PA_7,PA_6);

PID_ myPID2(1,1,1,1);

MenuLCD_::MenuLCD_(PinName inputButtonMenuOL, PinName inputButtonMenuCL):InputButtonMenu_(inputButtonMenuOL), inputButtonMenuCL_(inputButtonMenuCL)
{
    
    InputButtonMenu_.fall(callback(this, &MenuLCD_::ButtonFallOLMenu_));
    InputButtonMenu_.rise(callback(this, &MenuLCD_::ButtonRiseOLMenu_));

    inputButtonMenuCL_.fall(callback(this, &MenuLCD_::ButtonFallCLMenu_));
    inputButtonMenuCL_.rise(callback(this, &MenuLCD_::ButtonRiseCLMenu_));



}

//------------------------------------- Open Loop LCD Menu ---------------------------------------------------//

    void MenuLCD_::ButtonFallOLMenu_(void)
    {
        // Led_board_OL_Menu = 1;
        TimerOLMenu_.start();
    }

    void MenuLCD_::ButtonRiseOLMenu_(void)
    {
        // Led_3 = 1;
        // Led_board_OL_Menu = 0;
        // Led_OL_1 = 1;
        TimerOLMenu_.stop();

        if(!selectedFlagOL)
        {
            modeOL = !modeOL;
            TimerOLMenu_.reset();
            return;
        }

        selectedFlagOL  = true;
        TimerOLMenu_.reset();

    }

    void MenuLCD_::MenuDisplayOL_(float EncoderVal, float RPM)
    {
        if(!selectedFlagOL)
        {
            if(modeOL == 0)
            {
                    lcd_3.cls();
                    lcd_3.locate(0, 0);
                    lcd_3.printf("Desired Speed %%");
                    lcd_3.locate(0, 1);
                    lcd_3.printf("%f\n", EncoderVal); 
                    thread_sleep_for(500);
            }

            if(modeOL == 1)
            {
                    lcd_3.cls();
                    lcd_3.locate(0, 0);
                    lcd_3.printf("Speed (RPM):");
                    lcd_3.locate(0, 1);
                    lcd_3.printf("%1.0f\n", RPM);
                    thread_sleep_for(500);
            }
            wait_us(50e2);
        }
    }
    
 //------------------------------------- Closed Loop LCD Menu ---------------------------------------------------//

    void MenuLCD_::ButtonFallCLMenu_(void)
    {
        // Led_board_CL_Menu = 1;
        TimerCLMenu_.start();
    }

    void MenuLCD_::ButtonRiseCLMenu_(void)
    {
        // Led_3 = 1;
        // Led_board_CL_Menu = 0;
        // Led_CL_1 = 1;
        TimerCLMenu_.stop();

        if(!selectedFlagCL)
        {
            modeCL = !modeCL;
            TimerCLMenu_.reset();
            return;
        }

        selectedFlagCL  = true;
        TimerCLMenu_.reset();

    }

    // Create a menuLCD for closed loop
    void MenuLCD_::MenuDisplayCL_(float TS, float MS, float PWMPID)
    {
        if(!selectedFlagCL)
        {
            if(modeCL == 0)
            {
                    lcd_3.cls();
                    lcd_3.locate(0, 0);
                    lcd_3.printf("TS:");
                    lcd_3.locate(4,0);
                    lcd_3.printf("%1.f\n", TS);
                    
                    lcd_3.locate(0, 1);
                    lcd_3.printf("MS:");
                    lcd_3.locate(4, 1);
                    lcd_3.printf("%1.f\n", MS);
                    thread_sleep_for(500);
            }

            if(modeCL == 1)
            {
                    lcd_3.cls();
                    lcd_3.locate(0, 0);
                    lcd_3.printf("PID_PWM");
                    lcd_3.locate(0, 1);
                    lcd_3.printf("%4.f\n", PWMPID);
                    thread_sleep_for(500);
            }
            wait_us(50e2);
        }
    }
