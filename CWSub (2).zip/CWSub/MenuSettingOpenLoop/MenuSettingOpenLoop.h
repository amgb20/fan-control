/* Single Channel Encoder as Speedometer
   John Donnal 2018
*/
 
#ifndef MENU_LCD
#define MENU_LCD
 
/**
 * Includes
 */
#include "mbed.h"
#include <cstdint>
 
/**
 * Menu Interface.
 */
class MenuLCD_ {
 
public:
 
    /**
     * Constructor.
     *
     * Tracks rising and falling edges with interrupts
     *
     * @param inputButtonMenuOL mbed pin for External Button channel.
     * @param inputButtonMenuCL mbed pin for External Button channel.
     */
    MenuLCD_(PinName inputButtonMenuOL, PinName inputButtonMenuCL);
 
    /**
     * Display the Menu selection layout for Open Loop.
     *
     * Requires encoder input and the measured speed
     */
    void MenuDisplayOL_(float EncoderVal, float RPM);

    void MenuDisplayCL_(float TS, float MS, float PWMPID);


   
private:
 

    // interrupt functions for OL menu
    void ButtonFallOLMenu_(void);
    void ButtonRiseOLMenu_(void);

    // timer for OL
    Timer TimerOLMenu_;

    bool modeOL = 0;
    bool selectedFlagOL;

    InterruptIn InputButtonMenu_;

    // interrupt functions for CL menu
    void ButtonFallCLMenu_(void);
    void ButtonRiseCLMenu_(void);

    // timer for CL
    Timer TimerCLMenu_;

    bool modeCL = 0;
    bool selectedFlagCL;

    InterruptIn inputButtonMenuCL_;
    
};
 
#endif /* TACH_H */