/* Single Channel Encoder as Speedometer
   John Donnal 2018
*/
 
#ifndef TACH_H
#define TACH_H
 
/**
 * Includes
 */
#include "mbed.h"
#include <cstdint>
 
/**
 * Defines
 */
#define NSAMP 10
 
/**
 * Tach Interface.
 */
class Tach {
 
public:
 
    /**
     * Constructor.
     *
     * Tracks rising and falling edges with interrupts, provides
     * rotations per second (Hz) output
     *
     * @param input mbed pin for input channel.
     * @param pulsesPerRev Number of pulses in one revolution.
     */
    Tach(PinName input, int pulsesPerRev);
 
    /**
    * Get the speed of the fan
    * @return acc/NSAMP 
    */
    float           getSpeed(void);

    /**
    * Get the speed of the fan
    * @return count_ 
    */
    int             getCount(void);

    /**
    * Get the speed of the fan
    * @return freqAvg/NSAMP
    */
    float           getFreq(void);

    /**
    * Get the speed of the fan
    * @return dt_1 
    */
    float           getCounter(void);
   
private:
 
    /**
     * Update the pulse count.
     *
     * Called on every rising/falling edge of input
     *
     * update current speed estimate
     */
    void update(void);
 
    /**
     * Called on every rising edge of channel index to update revolution
     * count by one.
     */
    void index(void);
 
    InterruptIn input_;
    Timer timer_; // Timer for the update

    /**
    * Creating all the global variables for TachRead
    */    
    int          pulsesPerRev_;
    float        speed_;
    float        freq_;
    int          count_;
    float        dt_1;

    /**
    * The buffer take a NSAMP amount of value and will be accessed to average the speed
    */
    float        speedBuffer_[NSAMP];
    float        freqBuffer_[NSAMP];

};
 
#endif /* TACH_H */