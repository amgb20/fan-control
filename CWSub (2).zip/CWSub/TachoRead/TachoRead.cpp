#include "TachoRead.h"
#include "Encoder.h"
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <ctime>

// #define ROTARY_A_Tach PA_1 // Encoder pinA
// #define ROTARY_B_Tach PA_4 // Encoder pinB

// PinName Rotary_A_Tach(ROTARY_A_Tach);
// PinName Rotary_B_Tach(ROTARY_B_Tach);

// /**
// * Creating the QEI_ object
// */
// QEI_ myQEI_tach(Rotary_A_Tach, Rotary_B_Tach);

 /**
 * Initialising the Tach constructor
 */
 Tach::Tach(PinName input, int pulsesPerRev): input_(input){
    speed_       = 0.0;
    pulsesPerRev_ = pulsesPerRev;
    // input_.rise(callback(this, &Tach::update));
    input_.fall(callback(this, &Tach::update));
    timer_.start();
    for(int i=0;i<NSAMP;i++){
        speedBuffer_[i]=0.0;
    }
}

int Tach::getCount(void){
    return count_;
}

float Tach::getFreq(void){
    // return freq_;
    float freqAvg=0;
    for(int i=0;i<NSAMP;i++){
        freqAvg+=freqBuffer_[i];
    }
    return freqAvg/NSAMP;
}


float Tach::getSpeed(void) {

    float acc=0.0;

    float firstValue_ ;
    
    firstValue_ = speedBuffer_[0];

        // return speed_;
        for(int i=0;i<NSAMP;i++){

            if(firstValue_ != speedBuffer_[i])
            {
                acc+=speedBuffer_[i];
            }
            else {
                acc = 0.0;
            }    
        }
    
    return acc/NSAMP;
}

float Tach::getCounter(void)
{
    return dt_1;
}

void Tach::update(void) 
{
    float speed;
    static int i=0;
    static uint64_t int_us;

    int_us = timer_.elapsed_time().count();

    dt_1 = int_us;

    timer_.reset();
    timer_.start();

    // getting the frequency in seconds
    freq_ = 1000000.0/(int_us);

    /** low-pass filter to get rid of unwanted frequencies, ie unwanted parasite spikes
    * 75Hz is the maximum frequency we could experimentally record
    */
    if (freq_ < 75)
    {
        // converting the speed in RPM
        speed_ = 60.0*freq_/pulsesPerRev_;

        // putting every speed values in a buffer
        speedBuffer_[i%NSAMP]=speed_;

        freqBuffer_[i%NSAMP]=freq_;
    }
    
    i++;
    count_++;
}