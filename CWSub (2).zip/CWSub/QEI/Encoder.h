#ifndef QEI_H
#define QEI_H

/**
 * Includes
 */
#include "mbed.h"

/**
 * Defines Macros
 */
#define PREV_MASK 0x1 //Mask for the previous state in determining direction
//of rotation.
#define CURR_MASK 0x2 //Mask for the current state in determining direction
//of rotation.
#define INVALID   0x3 //XORing two states where both bits have changed.

/**
 * Quadrature Encoder Interface.
 */

 class QEI_ 
 {
     public:
        /**
        * Constructor.
        *
        * Reads the current values on channel A and channel B to determine the
        * initial state.
        *
        * Attaches the encode function to the rise/fall interrupt edges of
        * channels A and B to perform X4 encoding.
        *
        * Attaches the index function to the rise interrupt edge of channel index
        * (if it is used) to count revolutions.
        *
        * @param channelA mbed pin for channel A input.
        * @param channelB mbed pin for channel B input.
        */

        QEI_(PinName channelA, PinName channelB);
        /**
        * Reset the encoder.
        *
        * Sets the pulses and revolutions count to zero.
        */
        void reset_(void);

        /**
        * Read the state of the encoder.
        *
        * @return The current state of the encoder as a 2-bit number, where:
        *         bit 1 = The reading from channel B
        *         bit 2 = The reading from channel A
        */
        int getCurrentState_(void);

        /**
        * Read the number of pulses recorded by the encoder.
        *
        * @return Number of pulses which have occured.
        */
        int getPulses_(void);

        /**
        * @return PwmVal
        */
        float getPwmVal_(void);

        /**
        * Write the PWM value in FANPWM for open loop
        * requires the pwm input (value between 0 and 1 and float) of the desired speed
        */
        void writePWM_OL();


        /**
        * Write the PWM value in FANPWM for closed loop
        * requires the pwm input (value between 0 and 1 and float) of the desired speed
        */
        void writePWM_CL();
        
        /**
        * Update the pulse count.
        *
        * Called on every rising/falling edge of channels A/B.
        *
        * Reads the state of the channels and determines whether a pulse forward
        * or backward has occured, updating the count appropriately.
        */
        void encode_(void);
        // this function is used for PID control   
        void encodePID_(void);

    private:

    InterruptIn channelA_;
    InterruptIn channelB_;

    int          prevState_;
    int          currState_;

    volatile int pulses_;
    volatile float RectifyPulses_;
    volatile float RectifyPulses2Float_;

    volatile float PwmVal;

 };

#endif QEI_H