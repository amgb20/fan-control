/**
 * @author
 *
 * @section DESCRIPTION
 *
 * Quadrature Encoder Interface.
 *
 * A quadrature encoder consists of two code tracks on a disc which are 90
 * degrees out of phase. It can be used to determine how far a wheel has
 * rotated, relative to a known starting position.
 *
 * Only one code track changes at a time leading to a more robust system than
 * a single track, because any jitter around any edge won't cause a state
 * change as the other track will remain constant.
 *
 * Encoders can be a homebrew affair, consisting of infrared emitters/receivers
 * and paper code tracks consisting of alternating black and white sections;
 * alternatively, complete disk and PCB emitter/receiver encoder systems can
 * be bought, but the interface, regardless of implementation is the same.
 *
 *               +-----+     +-----+     +-----+
 * Channel A     |  ^  |     |     |     |     |
 *            ---+  ^  +-----+     +-----+     +-----
 *               ^  ^
 *               ^  +-----+     +-----+     +-----+
 * Channel B     ^  |     |     |     |     |     |
 *            ------+     +-----+     +-----+     +-----
 *               ^  ^
 *               ^  ^
 *               90deg
 *
 * The interface uses X2 encoding by default which calculates the pulse count
 * based on reading the current state after each rising and falling edge of
 * channel A.
 *
 *               +-----+     +-----+     +-----+
 * Channel A     |     |     |     |     |     |
 *            ---+     +-----+     +-----+     +-----
 *               ^     ^     ^     ^     ^
 *               ^  +-----+  ^  +-----+  ^  +-----+
 * Channel B     ^  |  ^  |  ^  |  ^  |  ^  |     |
 *            ------+  ^  +-----+  ^  +-----+     +--
 *               ^     ^     ^     ^     ^
 *               ^     ^     ^     ^     ^
 * Pulse count 0 1     2     3     4     5  ...
 *
 * This interface can also use X4 encoding which calculates the pulse count
 * based on reading the current state after each rising and falling edge of
 * either channel.
 *
 *               +-----+     +-----+     +-----+
 * Channel A     |     |     |     |     |     |
 *            ---+     +-----+     +-----+     +-----
 *               ^     ^     ^     ^     ^
 *               ^  +-----+  ^  +-----+  ^  +-----+
 * Channel B     ^  |  ^  |  ^  |  ^  |  ^  |     |
 *            ------+  ^  +-----+  ^  +-----+     +--
 *               ^  ^  ^  ^  ^  ^  ^  ^  ^  ^
 *               ^  ^  ^  ^  ^  ^  ^  ^  ^  ^
 * Pulse count 0 1  2  3  4  5  6  7  8  9  ...
 *
 * It defaults
 *
 * An optional index channel can be used which determines when a full
 * revolution has occured.
 *
 * If a 4 pules per revolution encoder was used, with X4 encoding,
 * the following would be observed.
 *
 *               +-----+     +-----+     +-----+
 * Channel A     |     |     |     |     |     |
 *            ---+     +-----+     +-----+     +-----
 *               ^     ^     ^     ^     ^
 *               ^  +-----+  ^  +-----+  ^  +-----+
 * Channel B     ^  |  ^  |  ^  |  ^  |  ^  |     |
 *            ------+  ^  +-----+  ^  +-----+     +--
 *               ^  ^  ^  ^  ^  ^  ^  ^  ^  ^
 *               ^  ^  ^  ^  ^  ^  ^  ^  ^  ^
 *               ^  ^  ^  +--+  ^  ^  +--+  ^
 *               ^  ^  ^  |  |  ^  ^  |  |  ^
 * Index      ------------+  +--------+  +-----------
 *               ^  ^  ^  ^  ^  ^  ^  ^  ^  ^
 * Pulse count 0 1  2  3  4  5  6  7  8  9  ...
 * Rev.  count 0          1           2
 *
 * Rotational position in degrees can be calculated by:
 *
 * (pulse count / X * N) * 360
 *
 * Where X is the encoding type [e.g. X4 encoding => X=4], and N is the number
 * of pulses per revolution.
 *
 * Linear position can be calculated by:
 *
 * (pulse count / X * N) * (1 / PPI)
 *
 * Where X is encoding type [e.g. X4 encoding => X=44], N is the number of
 * pulses per revolution, and PPI is pulses per inch, or the equivalent for
 * any other unit of displacement. PPI can be calculated by taking the
 * circumference of the wheel or encoder disk and dividing it by the number
 * of pulses per revolution.
 */

/**
 * Includes
 */
#include "mbed.h"
#include <cstdio>
#include <cstring>
#include "PIDControl.h"
#include "Encoder.h"
#include "TextLCD.h"
#include "MenuSettingOpenLoop.h"
// #include "MenuSettingClosedLoop.h"

/**
 Define
*/
#define LEDRED PC_0 // Led out red
#define PWMPOUT PB_0 //  PWM out pin
#define BUTTON_MENU_OPEN_LOOP PB_8 // Button for selection of menu
#define BUTTON_MENU_CLOSED_LOOP PC_5 // Button for selection of menu

/**
* Creating the breadboard button object
*/
PinName ButtonMenu_OL(BUTTON_MENU_OPEN_LOOP);
PinName ButtonMenu_CL(BUTTON_MENU_CLOSED_LOOP);

/**
* Creating the led object
*  DigitalOut(PinName pin) : gpio()
*/
DigitalOut led(LEDRED);

/**
* Creating the PWM fan object
* PwmOut(PinName pin)
*/
PwmOut FANPWM(PWMPOUT);

/**
* Creating the menu LCD object
* The contructor requires a PinName
* MenuLCD_(PinName inputButtonMenu)
*/
MenuLCD_ myMenuLCD(ButtonMenu_OL, ButtonMenu_CL);

// MenuClosedLoopLCD_ myMenuLCD_CL(ButtonMenu_CL);

/**
* Creating the LCD object
* Constructor requires TextLCD(PinName rs, PinName e, PinName d4, PinName d5, PinName d6, PinName d7, LCDType type = LCD16x2)
*/
TextLCD lcd_(PB_5,PB_4,PC_7,PB_6,PA_7,PA_6);

/**
* Creating the PID_ object
* Constructor requires  PID_(float Kd, float Ki, float Kp, float MaxSpeed)
* ------ Trial values -----
* float Kd = 3
* float Ki = 1
* float Kp = 1
* float MaxSpeed = 2300
*/
// PID constants (calcuated using Ziegler–Nichols method)
        // Ultimate Gain and Oscillation Period
        const constexpr float ku = 0.1;
        const constexpr float Tu = 1;
        // P
        const constexpr float P_kp = 0.5 * ku;
        // PI
        const constexpr float PI_kp = 0.45 * ku;
        const constexpr float PI_ki = (0.54 * ku) / Tu;
        // PD
        const constexpr float PD_kp = 0.8 * ku;
        const constexpr float PD_kd = 0.1 * ku * Tu;
        // PID
        const constexpr float PID_kp = 0.6 * ku;
        const constexpr float PID_ki = (1.2 * ku) / Tu;
        const constexpr float PID_kd = 0.075 * ku * Tu;

        // The values implemeted were found of hours of trial and error depending on the ultimate gain and oscillation period of our signal
PID_ myPID(PID_kd,PID_ki , PID_kp, 2000.0);


QEI_::QEI_(PinName channelA, PinName channelB): channelA_(channelA), channelB_(channelB)
{
    pulses_       = 0;
   
   //Workout what the current state is.
   int chanA = channelA_.read();
   int chanB = channelB_.read();
   //2-bit state.
   currState_ = (chanA << 1) | (chanB);
   prevState_ = currState_;

    //X4 encoding uses interrupts on channel A, and on channel B.
    channelA_.rise(callback(this, &QEI_::encode_));
    channelA_.fall(callback(this, &QEI_::encode_));
    
    channelB_.rise(callback(this, &QEI_::encode_));
    channelB_.fall(callback(this, &QEI_::encode_));
   
}

void QEI_::reset_(void) {

    pulses_      = 0;

}

int QEI_::getCurrentState_(void) {

    return currState_;

}

int QEI_::getPulses_(void) {

    return pulses_;

}

float QEI_::getPwmVal_(void){

    return PwmVal;
}

void QEI_::writePWM_OL()
{
    // assign the PWM value wanted
    float inputSpeedPWM_OL = QEI_::getPwmVal_();
    float MS_OL = myPID.PID_getMeasuredSpeed();

    // assign the speed desired to the menu
    float inputSpeedRPM_OL = RectifyPulses_ ;

    // if(inputSpeedRPM_OL <= 100)
    // {
    //     // printf("%f | %f \n", inputSpeedRPM_OL, myPID.PID_getMeasuredSpeed());
    //  myMenuLCD.MenuDisplayOL_(inputSpeedRPM_OL, myPID.PID_getMeasuredSpeed()); // create a function for rectify

    // }

    myMenuLCD.MenuDisplayOL_(inputSpeedRPM_OL, MS_OL); // create a function for rectify

    if(inputSpeedPWM_OL <= 0.0f)
            {
            FANPWM.write(0.0f);
        }
    else if(inputSpeedPWM_OL <= 1.0f)
        {
            FANPWM.write(inputSpeedPWM_OL);
        }
    else {
            FANPWM.write(0.0f);
    }
}

void QEI_::writePWM_CL()
{
    // assign the value of RectifyPulses to speedWanted flor clarification
    float speedWanted = RectifyPulses_;

    float TS = myPID.PID_getTargetSpeed();
    float MS = myPID.PID_getMeasuredSpeed();
    float PID_PWM = myPID.PID_getPwmSpeed();

    myMenuLCD.MenuDisplayCL_(TS, MS, PID_PWM);

    // starting the PID control
    myPID.PID_Implementation(speedWanted);

    // assigning the PWM that the PID value calculated
    float inputSpeedPWM_CL = myPID.PID_getPwmSpeed();

    if(inputSpeedPWM_CL <= 0.0f)
            {
            FANPWM.write(0.0f);
        }
    else if(inputSpeedPWM_CL < 1.0f)
        {
            // FANPWM.period(0.05); // 0.05 --> optimal set up so far
            // FANPWM.pulsewidth(2); // 0.1 --> optimal set-up for 0.3 pwm and below, 
            FANPWM.write(inputSpeedPWM_CL);
            // FANPWM.write(0.5);

        }
    
    else {
            FANPWM.write(0.0f);
    }
}
/** ADD A PWMVAL VOID FUNCTION SO WE CAN HAVE ONE FUNCTION READING ENCODER POSITION AND THEN CREATE AN OPEN-LOOP 
    PWM WRITE FUNCTION
*/

void QEI_::encode_(void)
{
    int change = 0;
    int chanA  = channelA_.read();
    int chanB  = channelB_.read();

    //2-bit state.
    currState_ = (chanA << 1) | (chanB);

    if (((currState_ ^ prevState_) != INVALID) && (currState_ != prevState_)) 
        {
            //2 bit state. Right hand bit of prev XOR left hand bit of current
            //gives 0 if clockwise rotation and 1 if counter clockwise rotation.
            change = (prevState_ & PREV_MASK) ^ ((currState_ & CURR_MASK) >> 1);

            if (change == 0) {
                pulses_--;
            }
            else{
                pulses_++;
            }

        }

    // One click is converted into one increment and converted into float
    RectifyPulses_ = (float) pulses_/4;
    
    // One click is converted into a value between 0 and 1
    RectifyPulses2Float_ = RectifyPulses_/100;
    
    // This value will set up the pwm value inside the write function
    PwmVal = RectifyPulses2Float_;
    
    prevState_ = currState_;

}
