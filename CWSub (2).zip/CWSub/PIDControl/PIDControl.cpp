#include <chrono>
#include <cstdint>
#include <cstdio>

#include "PIDControl.h"
#include "TachoRead.h"

#define TACHOREAD PA_0 // Tacho out pin

PinName TachoRead_Pin(TACHOREAD);

Tach myFanTach(TachoRead_Pin, 2);

PID_::PID_(float Kd, float Ki, float Kp, float MaxSpeed)
{
    _Kd = Kd;
    _Ki = Ki;
    _Kp = Kp;
    _maxSpeed = MaxSpeed;
}

float PID_::PID_getPwmSpeed(void)
{
    return pid_speed_PWM;
}

float PID_::PID_getTime(void)
{
    return dt_;
}

float PID_::PID_getMeasuredSpeed(void)
{
    return myFanTach.getSpeed();

}

float PID_::PID_getTargetSpeed(void)
{
    return TargetSpeed_/2;
}

float PID_::PID_getMeasuredElapsedTime(void)
{
    float b = myFanTach.getFreq();
    // return b/1e6;
    return b;

}

// PID implementation
void PID_::PID_Implementation(float WantedSpeed)
{
    static uint64_t int_us_1;

    _RectifyPulses = WantedSpeed;
    // rpm
    TargetSpeed_ = 50 * _RectifyPulses; // it seems that with the current configuration it works fine but show half of target speed

    MeasuredSpeed_ = myFanTach.getSpeed();

    // MeasureElapsedTime_ = myFanTach.getCounter();

    // MeasuredSpeed_ =  PID_getMeasuredSpeed();

    error_ = abs(TargetSpeed_ - MeasuredSpeed_);

    int_us_1 = timer_1.elapsed_time().count();

    dt_ = int_us_1/1e6;

    timer_1.reset();
    timer_1.start();

    // pid_speed in RPM
    pid_speed_RPM = _Kd * error_ * dt_ + _Ki * error_/dt_ + _Kp * error_;

    // pwm float (betewen 0 and 1)
    pid_speed_PWM = pid_speed_RPM / _maxSpeed;
    
    printf("RectifyPulses %f | TargetSpeed %f | MeasuredSpeed %f | PIDSpeedRPM %f | PIDSpeedPWM %f | error %f | dt %f  \n",_RectifyPulses, TargetSpeed_, MeasuredSpeed_,pid_speed_RPM, pid_speed_PWM, error_ , dt_);

}


                        