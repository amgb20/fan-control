#ifndef PID_Control
#define PID_Control

#include "mbed.h"

class PID_
{
    public:

    /**
    * Construtor
    * Reads the current value of the PID control values Ki, Kp and Kd
    * 
    * @param Kd
    * @param Ki
    * @param Kp
    * @param MaXSpeed
    */

    PID_(float Kd, float Ki, float Kp, float MaxSpeed);

    /**
    * Calcultes the speed within the PID control loop
    */
    void PID_Implementation(float WantedSpeed);

    /**
    * Returns the speed in the PWM function
    */
    float PID_getPwmSpeed(void);

    float PID_getTime(void);

    float PID_getMeasuredSpeed(void);

    float PID_getMeasuredElapsedTime(void);

    float PID_getTargetSpeed(void);

    private:

    Timer timer_1 ;

    volatile float TargetSpeed_ ;
    volatile float MeasuredSpeed_ ;
    volatile float MeasureElapsedTime_;
    volatile float pid_speed_RPM;
    volatile float pid_speed_PWM;
    volatile float _RectifyPulses;
    volatile float error_;
    float dt_;
    
    float _Kd;
    float _Ki;
    float _Kp;
    float _maxSpeed;

};

#endif


